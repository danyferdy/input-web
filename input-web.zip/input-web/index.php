<!DOCTYPE html>
<html>
<head>
    <title>Input Data Pelanggan</title>
</head>
<body>
    <h2>Input Data Pelanggan</h2>
    <form action="proses.php" method="POST">
        <label for="nama">Nama:</label>
        <input type="text" name="nama" required><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
