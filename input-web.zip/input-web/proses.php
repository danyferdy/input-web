<?php
// Menghubungkan dengan database
$host = "localhost:3306";
$user = "root";
$password = "izza";
$database = "pelanggan";

$koneksi = mysqli_connect($host, $user, $password, $database);

// Memeriksa koneksi
if (mysqli_connect_errno()) {
    echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
    exit();
}

// Memproses data yang dikirimkan
$nama = $_POST['nama'];
$email = $_POST['email'];

// Menyimpan data ke database
$query = "INSERT INTO pelanggan (nama, email) VALUES ('$nama', '$email')";
$result = mysqli_query($koneksi, $query);

// Memeriksa apakah data berhasil disimpan
if ($result) {
    echo "Data berhasil disimpan.";
} else {
    echo "Gagal menyimpan data: " . mysqli_error($koneksi);
}

// Menutup koneksi database
mysqli_close($koneksi);
?>
